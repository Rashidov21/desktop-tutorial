const App = {
    data() {
        return {
            list:true,
            posts:[
                {title:"Windows 11"},
                {title:"Python 3.9"},
                {title:"How to install Ubuntu"},
                {title:"Learn Vue.Js 3"},
            ]
           
        }
    },

}
const app = Vue.createApp(App);
app.mount('#app');

// let  posts = [
//                 {title:"Windows 11"},
//                 {title:"Python 3.9"},
//                 {title:"How to install Ubuntu"},
//                 {title:"Learn Vue.Js 3"},
//             ]
// for(let i = 0; i < posts.length;i++){
//     console.log(posts[i].title)
// }
// for (let key of posts){
//     console.log(key)
// }

const TodoApp = {
   
    data() {
       return {
         show:false,
         newtodo:'',

           todos:[
               {
                name:'Learn Programming ',
                done:false
                },

            ]
       }
    },
    methods: {
        add:function(){
            if(this.newtodo !== ''){
                this.todos.push(
                    {name:this.newtodo,done:false}
                );
                this.newtodo = '';
            }else{
                this.show = true
            }
            
        },
        remove:function(key){
            this.todos.splice(key)
        }
    }
}
const todo = Vue.createApp(TodoApp).mount('#todo')

document.addEventListener("keydown", function(event) {
  if(event.which == 13){
    todo.add()
  }
})